package me.morecommands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public class LookAtInvCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Check if command is enabled in config
        if (!PaperPlugin.getInstance().getConfig().getBoolean("commands.lookatinv", true)) {
            sender.sendMessage("This command is disabled in the config.");
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        if (!player.hasPermission("morecommands.lookatinv") && !player.isOp()) {
            player.sendMessage("You do not have permission to use this command.");
            return true;
        }

        if (args.length != 1) {
            player.sendMessage("Usage: /lookatinv <playerusername>");
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null || !target.isOnline()) {
            player.sendMessage("Player not found or not online.");
            return true;
        }

        Inventory targetInv = target.getInventory();
        player.openInventory(targetInv);
        player.sendMessage("You are now viewing " + target.getName() + "'s inventory.");
        return true;
    }
}