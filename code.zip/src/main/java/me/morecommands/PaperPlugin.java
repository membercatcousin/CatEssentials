package me.morecommands;

import org.bukkit.plugin.java.JavaPlugin;

public class PaperPlugin extends JavaPlugin {
    private static PaperPlugin instance;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig(); // Loads config.yml if not present
        getCommand("lookatinv").setExecutor(new LookAtInvCommand());
    }

    public static PaperPlugin getInstance() {
        return instance;
    }
}

